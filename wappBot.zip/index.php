<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>wappBot - Chat Bot Powered by Artificial Intelligence #1</title>

		<script src="assets/js/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="assets/css/all.css">
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<script src="assets/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<div class="login">
			<h1>wappBot Login</h1>
			<?php if (isset($_GET['error'])): ?>
				<div class="alert alert-danger wappalertred" role="alert">
					Your username or password does not match.
				</div>
			<?php endif ?>
			<form action="authenticate.php" method="post">
				<label for="username">
					<i class="fas fa-user"></i>
				</label>
				<input type="text" name="username" placeholder="Username" id="username" required>
				<label for="password">
					<i class="fas fa-lock"></i>
				</label>
				<input type="password" name="password" placeholder="Password" id="password" required>
				<input type="submit" value="Login">
			</form>
		</div>
	</body>
</html>